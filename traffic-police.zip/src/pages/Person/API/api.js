import request from './http'

export function MY_GET(url, params) {
  return request({
    method: 'get',
    url,
    params
  })
}

export function MY_POST_DATA(url, data) {
  return request({
    method: 'post',
    url,
    data
  })
}

export function MY_POST_QUERY(url, params) {
  return request({
    method: 'post',
    url,
    params
  })
}

export function MY_POST_UPLOAD(url, data, params) {
  return request({
    url,
    method: 'post',
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    data,
    params
  })
}